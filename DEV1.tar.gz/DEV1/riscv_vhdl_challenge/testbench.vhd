library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;

entity testbench is
end entity;

architecture behavior of testbench is

    -- Clock and reset signals
    signal clk      : std_logic := '0';
    signal resetn   : std_logic := '0';

    -- Memory interface signals
    signal mem_valid  : std_logic;
    signal mem_instr  : std_logic;
    signal mem_ready  : std_logic := '0';
    signal mem_addr   : std_logic_vector(31 downto 0);
    signal mem_wdata  : std_logic_vector(31 downto 0);
    signal mem_wstrb  : std_logic_vector(3 downto 0);
    signal mem_rdata  : std_logic_vector(31 downto 0);
    signal mem_dbg    : std_logic_vector(7 downto 0);

    -- IRQ signals
    signal irq       : std_logic := '0';
    signal irq_time  : unsigned(31 downto 0) := (others => '0');

    -- Memory array: 256KB / 4 = 65536 words
    type memory_array_t is array (0 to 65535) of std_logic_vector(31 downto 0);
    signal memory : memory_array_t := (others => (others => '0'));

    -- Delay counter
    signal count_dly : unsigned(2 downto 0) := (others => '0');
    signal first_fill       : std_logic := '0';

    -- File handling for firmware
    file firmware_file : text open read_mode is "firmware/test.hex";

    -- Helper function to convert hex character to 4-bit std_logic_vector
    function hex_char_to_slv(c : character) return std_logic_vector is
    begin
        case c is
            when '0' => return "0000";
            when '1' => return "0001";
            when '2' => return "0010";
            when '3' => return "0011";
            when '4' => return "0100";
            when '5' => return "0101";
            when '6' => return "0110";
            when '7' => return "0111";
            when '8' => return "1000";
            when '9' => return "1001";
            when 'a' | 'A' => return "1010";
            when 'b' | 'B' => return "1011";
            when 'c' | 'C' => return "1100";
            when 'd' | 'D' => return "1101";
            when 'e' | 'E' => return "1110";
            when 'f' | 'F' => return "1111";
            when others =>
                report "Invalid hex character: " & c severity error;
                return "0000";
        end case;
    end function;


begin


    -- Clock generation: 10 ns period (100 MHz)
    clk_process : process
    begin
        wait for 5 ns;
        clk <= not clk;
    end process;

    -- Reset generation: hold reset low for 5 clock cycles
    reset_process : process
    begin
        resetn <= '0';
        wait for 50 ns;  -- 5 clock cycles @ 10 ns period
        resetn <= '1';
        wait;
    end process;

    -- Instantiate riscv core component
    riscv_core_inst : entity work.riscv
        port map (
            clk       => clk,
            resetn    => resetn,

            mem_valid => mem_valid,
            mem_addr  => mem_addr,
            mem_wdata => mem_wdata,
            mem_wstrb => mem_wstrb,
            mem_instr => mem_instr,
            mem_ready => mem_ready,
            mem_rdata => mem_rdata
        );

    -- Assign debug signal (lowest byte of memory(0))
    mem_dbg <= memory(0)(7 downto 0);

    -- Memory and IRQ handling process
    mem_irq_process : process(clk)
        variable line_in : line;
	variable line_out : line;
        variable addr_int : integer;
        variable wstrb_int : std_logic_vector(3 downto 0);
	
        --variable line_in : line;
        variable hex_str : string(1 to 8);
        variable idx : integer := 0;
        variable word_slv : std_logic_vector(31 downto 0);
	variable c : character;
	
        constant CR : std_logic_vector(7 downto 0) := x"0D";  -- Carriage Return
        constant LF : std_logic_vector(7 downto 0) := x"0A";  -- Line Feed	
	
    begin
        if resetn = '0' then
                mem_ready <= '0';
                mem_rdata <= (others => '0');
        elsif rising_edge(clk) then
                -- Memory interface

		if first_fill = '0' then
	        	idx := 0;
	
	        	while not endfile(firmware_file) and idx <= 65533 loop
		            readline(firmware_file, line_in);

        		    -- Read first 8 characters from the line as hex string
	        	    -- If line length is less than 8, report error
		            if line_in'length < 8 then
        		        --report "Line too short for 32-bit hex word" severity error;
				exit;
		            end if;

        		    -- Read exactly 8 characters
	        	    for i in 1 to 8 loop                
        	        	read(line_in, c);
	                	hex_str(i) := c;
		            end loop;

        		    -- Convert hex string to std_logic_vector
		            for i in 0 to 7 loop
        		        word_slv(31 - i*4 downto 28 - i*4) := hex_char_to_slv(hex_str(i+1));
	        	    end loop;

	        	    -- Store in memory
		            memory(idx) <= word_slv;

        		    --report "Memory(" & integer'image(idx) & ") <= " & to_hstring(word_slv);
			    --report "Memory(" & integer'image(idx) & ") <= " & to_hstring(memory(idx));

        		    idx := idx + 1;
		        end loop;
			first_fill <= '1';
		end if;	
		
		
                if mem_valid = '1' and mem_ready = '0' then
                    -- No LONG_READY delay implemented here, immediate ready
                    mem_ready <= '1';		    
		    addr_int := to_integer(unsigned(mem_addr(31 downto 2)));
		    --report "addr_int: " & integer'image(addr_int);
		    --report "memory(addr_int): " & to_hstring(memory(addr_int));
                    if mem_wstrb /= "0000" then
                        -- Handle special addresses
                        if mem_addr = x"10000000" then
                            -- Write character to console
                            -- VHDL does not support direct $write equivalent in simulation
                            -- Use textio to write to console
                            --if mem_wdata(7 downto 0) = LF then			    
			    if mem_wdata(7 downto 0) /= LF then
			        write(line_out, character'val(to_integer(unsigned(mem_wdata(7 downto 0)))));
			    else
			        --report "EOL detected: " & to_hstring(mem_wdata(7 downto 0));
				writeline(output, line_out);				
			    end if;			    
			    --else				    			    
			    --end if;                            
                        else
                            -- Write to memory with byte enables
                            if mem_wstrb(0) = '1' then
                                memory(addr_int)(7 downto 0) <= mem_wdata(7 downto 0);
                            end if;
                            if mem_wstrb(1) = '1' then
                                memory(addr_int)(15 downto 8) <= mem_wdata(15 downto 8);
                            end if;
                            if mem_wstrb(2) = '1' then
                                memory(addr_int)(23 downto 16) <= mem_wdata(23 downto 16);
                            end if;
                            if mem_wstrb(3) = '1' then
                                memory(addr_int)(31 downto 24) <= mem_wdata(31 downto 24);
                            end if;
                        end if;
                    else
                        -- Read from memory
                        mem_rdata <= memory(addr_int);
                    end if;
                else
                    mem_ready <= '0';
                end if;
        end if;
    end process;

    -- Firmware loading (simulation only)
    -- Note: VHDL does not have a direct equivalent of $readmemh.
    -- You can implement this with file reading in a separate process or pre-load memory via a script.
    -- For simplicity, memory is initialized to zero here.

end architecture;
