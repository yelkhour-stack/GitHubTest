library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity riscv is
  port (
    clk        : in  std_logic;
    resetn     : in  std_logic;

    mem_valid  : out std_logic;
    mem_instr  : out std_logic;
    mem_ready  : in  std_logic;

    mem_addr   : out std_logic_vector(31 downto 0);
    mem_wdata  : out std_logic_vector(31 downto 0);
    mem_wstrb  : out std_logic_vector(3 downto 0);
    mem_rdata  : in  std_logic_vector(31 downto 0)
  );
end entity;

architecture rtl of riscv is

  -- Signals
  signal count_cycle       : std_logic_vector(63 downto 0) := (others => '0');
  signal count_instr       : std_logic_vector(63 downto 0) := (others => '0');

  signal new_ascii_instr   : std_logic_vector(63 downto 0);
  signal new_rs1           : std_logic_vector(63 downto 0);
  signal new_rs2           : std_logic_vector(63 downto 0);
  signal new_rd            : std_logic_vector(63 downto 0);

  signal alu_valid         : std_logic;
  signal alu_a, alu_b      : std_logic_vector(31 downto 0);
  signal aluop             : std_logic_vector(3 downto 0);
  signal aluout            : std_logic_vector(31 downto 0);
  signal alu_ready         : std_logic;
  signal over              : std_logic;
  signal zero              : std_logic;
  signal operandzero       : std_logic;

  signal regram_wen        : std_logic;
  signal regram_wrdata     : std_logic_vector(31 downto 0);
  signal regram_rdata1_nozero : std_logic_vector(31 downto 0);
  signal regram_rdata2_nozero : std_logic_vector(31 downto 0);
  signal regram_rdata1     : std_logic_vector(31 downto 0);
  signal regram_rdata2     : std_logic_vector(31 downto 0);
  signal regram_waddr      : std_logic_vector(5 downto 0);
  signal regram_raddr1     : std_logic_vector(5 downto 0);
  signal regram_raddr2     : std_logic_vector(5 downto 0);

  -- CPU states  
  signal cpu_state         : std_logic_vector(1 downto 0);

  signal mem_valid_fetch   : std_logic := '0';
  signal mem_valid_execute : std_logic;

  signal mem_data_reg      : std_logic_vector(31 downto 0) := (others => '0');
  signal pc_reg            : std_logic_vector(31 downto 0) := (others => '0');
  signal branch_pc_reg     : std_logic_vector(31 downto 0);

  signal imm_s_type_reg    : std_logic_vector(11 downto 0);
  signal imm_i_type_reg    : std_logic_vector(11 downto 0);
  signal imm_b_type_reg    : std_logic_vector(12 downto 0);
  signal imm_j_type_reg    : std_logic_vector(20 downto 0);
  signal imm_u_type_reg    : std_logic_vector(31 downto 0);

  signal rs1_reg           : std_logic_vector(4 downto 0);
  signal rs2_reg           : std_logic_vector(4 downto 0);
  signal rd_reg            : std_logic_vector(4 downto 0);
  signal wrdata_reg        : std_logic_vector(31 downto 0);

  signal mem_dest          : std_logic_vector(31 downto 0) := (others => '0'); --default value to overcome bound check failure at 0
  signal mem_src           : std_logic_vector(31 downto 0);

  signal branch_cond       : std_logic;

  signal cpuregs_rs1       : std_logic_vector(31 downto 0);
  signal cpuregs_rs2       : std_logic_vector(31 downto 0);

  signal byte_memsrc       : std_logic_vector(3 downto 0);
  signal byte_memdest      : std_logic_vector(4 downto 0);

    constant const32 : std_logic_vector(31 downto 0) := (others => '0');
    constant fetch : std_logic_vector(1 downto 0) := (others => '0');
    constant decode : std_logic_vector(1 downto 0) := "01";
    constant exec : std_logic_vector(1 downto 0) := "10";
    
    signal func3              : std_logic_vector(2 downto 0);
    signal func7              : std_logic_vector(6 downto 0);
    signal major_opcode       : std_logic_vector(6 downto 0);
    signal inst_r_opcode      : std_logic_vector(3 downto 0);
    signal inst_i_opcode      : std_logic_vector(3 downto 0);
    
    signal dbg_x0  : std_logic_vector(31 downto 0);
    signal dbg_x1  : std_logic_vector(31 downto 0);
    signal dbg_x2  : std_logic_vector(31 downto 0);
    signal dbg_x3  : std_logic_vector(31 downto 0);
    signal dbg_x4  : std_logic_vector(31 downto 0);
    signal dbg_x5  : std_logic_vector(31 downto 0);
    signal dbg_x6  : std_logic_vector(31 downto 0);
    signal dbg_x7  : std_logic_vector(31 downto 0);
    signal dbg_x8  : std_logic_vector(31 downto 0);
    signal dbg_x9  : std_logic_vector(31 downto 0);
    signal dbg_x10 : std_logic_vector(31 downto 0);
    signal dbg_x11 : std_logic_vector(31 downto 0);
    signal dbg_x12 : std_logic_vector(31 downto 0);
    signal dbg_x13 : std_logic_vector(31 downto 0);
    signal dbg_x14 : std_logic_vector(31 downto 0);
    signal dbg_x15 : std_logic_vector(31 downto 0);
    signal dbg_x16 : std_logic_vector(31 downto 0);
    signal dbg_x17 : std_logic_vector(31 downto 0);
    signal dbg_x18 : std_logic_vector(31 downto 0);
    signal dbg_x19 : std_logic_vector(31 downto 0);
    signal dbg_x20 : std_logic_vector(31 downto 0);
    signal dbg_x21 : std_logic_vector(31 downto 0);
    signal dbg_x22 : std_logic_vector(31 downto 0);
    signal dbg_x23 : std_logic_vector(31 downto 0);
    signal dbg_x24 : std_logic_vector(31 downto 0);
    signal dbg_x25 : std_logic_vector(31 downto 0);
    signal dbg_x26 : std_logic_vector(31 downto 0);
    signal dbg_x27 : std_logic_vector(31 downto 0);
    signal dbg_x28 : std_logic_vector(31 downto 0);
    signal dbg_x29 : std_logic_vector(31 downto 0);
    signal dbg_x30 : std_logic_vector(31 downto 0);
    signal dbg_x31 : std_logic_vector(31 downto 0);
    
    signal instr_group    : std_logic_vector(79 downto 0);
    signal i_type, r_type, b_type, l_type, s_type : std_logic;			
    signal instr_jal, instr_jalr, instr_beq, instr_bne, instr_blt, instr_bge, instr_bltu, instr_bgeu : std_logic;
    signal instr_lui, instr_auipc : std_logic; 	
    signal instr_ecall_ebreak, instr_rdcycle, instr_rdcycleh, instr_rdinstr, instr_rdinstrh : std_logic;	  
    
      
begin
  
    b_type <= instr_group(2);
    instr_lui  <= instr_group(10);
    instr_auipc<= instr_group(11);

    instr_jal  <= instr_group(20);
    instr_jalr <= instr_group(21);
    instr_beq  <= instr_group(22);
    instr_bne  <= instr_group(23);
    instr_blt  <= instr_group(24);
    instr_bge  <= instr_group(25);
    instr_bltu <= instr_group(26);
    instr_bgeu <= instr_group(27);
    
    instr_ecall_ebreak <= instr_group(70);
    instr_rdcycle      <= instr_group(71);
    instr_rdcycleh     <= instr_group(72);
    instr_rdinstr      <= instr_group(73);
    instr_rdinstrh     <= instr_group(74);    

  -- Zero detection
  zero <= '1' when aluout = const32 else '0';
  operandzero <= '1' when alu_a = const32 and alu_b = const32 else '0';

  -- Register file read data with zero check
  regram_rdata1 <= (others => '0') when rs1_reg = "00000" else regram_rdata1_nozero;
  regram_rdata2 <= (others => '0') when rs2_reg = "00000" else regram_rdata2_nozero;

  -- Branch condition logic (simplified, use appropriate std_logic logic)
  branch_cond <= '1' when
    (instr_beq  = '1' and zero = '1') or
    (instr_bne  = '1' and zero = '0' and operandzero = '0') or
    (instr_blt  = '1' and zero = '0' and over = '1') or
    (instr_bge  = '1' and over = '0') or
    (instr_bge  = '1' and zero = '1') or
    (instr_bltu = '1' and zero = '0' and over = '1') or
    (instr_bgeu = '1' and over = '0') or
    (instr_bgeu = '1' and zero = '1')
    else '0';

  -- Assign CPU registers outputs
  cpuregs_rs1 <= regram_rdata1;
  cpuregs_rs2 <= regram_rdata2;

  -- Assign byte_memsrc signals based on mem_src(1 downto 0)
  byte_memsrc(0) <= '1' when mem_src(1 downto 0) = "00" else '0';
  byte_memsrc(1) <= '1' when mem_src(1 downto 0) = "01" else '0';
  byte_memsrc(2) <= '1' when mem_src(1 downto 0) = "10" else '0';
  byte_memsrc(3) <= '1' when mem_src(1 downto 0) = "11" else '0';

  -- Assign byte_memdest (shift left by 3 bits)
  byte_memdest <= mem_dest(1 downto 0) & "000";

  -- Assign wrdata_reg
  wrdata_reg <= (others => '0') when (rd_reg = "00000") else regram_wrdata;

  -- Submodule instantiations

  ALUsync_i : entity work.ALUsync
    port map (
      clk    => clk,
      resetn => resetn,
      valid  => alu_valid,
      a      => alu_a,
      b      => alu_b,
      ALUop  => aluop,
      ALUOut => aluout,
      ready  => alu_ready,
      over   => over
    );

  ram_cpuregs : entity work.riscv_reg
    port map (
      clk    => clk,
      wen    => resetn and regram_wen,
      wdata  => wrdata_reg,
      rdata1 => regram_rdata1_nozero,
      rdata2 => regram_rdata2_nozero,
      waddr  => '0' & rd_reg,
      raddr1 => '0' & rs1_reg,
      raddr2 => '0' & rs2_reg,
      -- Debug ports omitted for brevity
      dbg_x0 => dbg_x0, 
      dbg_x1 => dbg_x1, 
      dbg_x2 => dbg_x2, 
      dbg_x3 => dbg_x3, 
      dbg_x4 => dbg_x4, 
      dbg_x5 => dbg_x5, 
      dbg_x6 => dbg_x6, 
      dbg_x7 => dbg_x7, 
      dbg_x8 => dbg_x8, 
      dbg_x9 => dbg_x9, 
      dbg_x10 => dbg_x10,
      dbg_x11 => dbg_x11,
      dbg_x12 => dbg_x12,
      dbg_x13 => dbg_x13,
      dbg_x14 => dbg_x14,
      dbg_x15 => dbg_x15,
      dbg_x16 => dbg_x16,
      dbg_x17 => dbg_x17,
      dbg_x18 => dbg_x18,
      dbg_x19 => dbg_x19,
      dbg_x20 => dbg_x20,
      dbg_x21 => dbg_x21,
      dbg_x22 => dbg_x22,
      dbg_x23 => dbg_x23,
      dbg_x24 => dbg_x24,
      dbg_x25 => dbg_x25,
      dbg_x26 => dbg_x26,
      dbg_x27 => dbg_x27,
      dbg_x28 => dbg_x28,
      dbg_x29 => dbg_x29,
      dbg_x30 => dbg_x30,
      dbg_x31 => dbg_x31
    );

  u_instruction_decoder : entity work.instruction_decoder
    port map (
      mem_data_reg       => mem_data_reg,
      instr_group        => instr_group,
      func3              => func3,
      func7              => func7,
      major_opcode       => major_opcode,
      inst_r_opcode      => inst_r_opcode,
      inst_i_opcode      => inst_i_opcode,
      rs1_reg            => rs1_reg,
      rs2_reg            => rs2_reg,
      rd_reg             => rd_reg,
      imm_s_type_reg     => imm_s_type_reg,
      imm_i_type_reg     => imm_i_type_reg,
      imm_b_type_reg     => imm_b_type_reg,
      imm_j_type_reg     => imm_j_type_reg,
      imm_u_type_reg     => imm_u_type_reg
    );

  cpu_decode_inst : entity work.cpu_decode
    port map (
      clk               => clk,
      resetn            => resetn,
      pc_reg            => pc_reg,
      cpu_state         => cpu_state,
      instr_group       => instr_group,
      imm_s_type_reg    => imm_s_type_reg,
      imm_i_type_reg    => imm_i_type_reg,
      imm_u_type_reg    => imm_u_type_reg,
      imm_j_type_reg    => imm_j_type_reg,
      imm_b_type_reg    => imm_b_type_reg,
      cpuregs_rs1       => cpuregs_rs1,
      cpuregs_rs2       => cpuregs_rs2,
      func3             => func3,
      new_rs1           => new_rs1,
      new_rs2           => new_rs2,
      new_rd            => new_rd,
      inst_i_opcode     => inst_i_opcode,
      inst_r_opcode     => inst_r_opcode,
      counter_reg       => count_cycle(31 downto 0),
      mem_dest          => mem_dest,
      mem_src           => mem_src,
      alu_ready         => alu_ready,
      alu_a             => alu_a,
      alu_b             => alu_b,
      alu_valid         => alu_valid,
      aluop             => aluop,
      branch_pc_reg     => branch_pc_reg
    );

  cpu_exec_inst : entity work.cpu_exec
    port map (
      clk               => clk,
      resetn            => resetn,
      pc_reg            => pc_reg,
      instr_group       => instr_group,
      counter_reg       => count_cycle(31 downto 0),
      counter_instr_reg => count_instr(31 downto 0),
      mem_dest          => mem_dest,
      mem_src           => mem_src,
      imm_u_type_reg    => imm_u_type_reg,
      aluout            => aluout,
      branch_pc_reg     => branch_pc_reg,
      mem_rdata         => mem_rdata,
      rd_reg            => rd_reg,
      cpuregs_rs1       => regram_rdata1,
      cpuregs_rs2       => regram_rdata2,
      byte_memdest      => byte_memdest,
      byte_memsrc       => byte_memsrc,
      alu_ready         => alu_ready,
      mem_ready         => mem_ready,
      mem_valid         => mem_valid,
      cpu_state         => cpu_state,
      regram_wen        => regram_wen,
      regram_wrdata     => regram_wrdata,
      mem_valid_execute => mem_valid_execute,
      branch_cond       => branch_cond,
      mem_addr          => mem_addr,
      mem_wdata         => mem_wdata,
      mem_wstrb         => mem_wstrb
    );

  mem_valid <= mem_valid_execute or mem_valid_fetch; 

  -- Main process for CPU state machine and counters
  process(clk, resetn)
  begin
    if resetn = '0' then
      mem_valid_fetch <= '0';
      mem_data_reg <= (others => '0');
      cpu_state <= fetch;
      pc_reg <= (others => '0');
      count_cycle <= (others => '0');
      count_instr <= (others => '0');            
    elsif rising_edge(clk) then
    
      count_cycle <= std_logic_vector(unsigned(count_cycle) + 1);

      -- Fetch state
      if cpu_state = fetch then
        if mem_ready = '0' then
          mem_valid_fetch <= '1';
        elsif mem_valid_fetch = '1' then
          mem_valid_fetch <= '0';
          cpu_state <= decode;
          mem_data_reg <= mem_rdata;
        end if;

      -- Decode state
      elsif cpu_state = decode then
        count_instr <= std_logic_vector(unsigned(count_instr) + 1);
        pc_reg <= std_logic_vector(unsigned(pc_reg) + 4);
        cpu_state <= exec;

      -- Exec state
      elsif cpu_state = exec then
        if alu_ready = '1' or (mem_valid = '1' and mem_ready = '1') 
	   or instr_lui = '1' or instr_rdcycle = '1' or instr_rdinstr = '1' then
          cpu_state <= fetch;
        end if;

        if b_type = '1' and alu_ready = '1' and branch_cond = '1' then
          pc_reg <= branch_pc_reg;
        elsif (instr_jal = '1' or instr_jalr = '1') and alu_ready = '1' then
          pc_reg <= aluout;
        end if;
      end if;
    end if;
    
  end process;

end architecture rtl;
