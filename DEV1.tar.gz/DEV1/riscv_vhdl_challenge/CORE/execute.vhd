library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity cpu_exec is
    port (
        clk               : in  std_logic;
        resetn            : in  std_logic;
	instr_group       : in std_logic_vector(79 downto 0);
        pc_reg            : in  std_logic_vector(31 downto 0);
        counter_reg       : in  std_logic_vector(31 downto 0);
        counter_instr_reg : in  std_logic_vector(31 downto 0);
        mem_dest          : in  std_logic_vector(31 downto 0);
        mem_src           : in  std_logic_vector(31 downto 0);
        imm_u_type_reg    : in  std_logic_vector(31 downto 0);
        aluout            : in  std_logic_vector(31 downto 0);
        branch_pc_reg     : in  std_logic_vector(31 downto 0);
        mem_rdata         : in  std_logic_vector(31 downto 0);
        rd_reg            : in  std_logic_vector(4 downto 0);
        cpuregs_rs1       : in  std_logic_vector(31 downto 0);
        cpuregs_rs2       : in  std_logic_vector(31 downto 0);
        byte_memdest      : in  std_logic_vector(4 downto 0);
        byte_memsrc       : in  std_logic_vector(3 downto 0);
        alu_ready         : in  std_logic;
        cpu_state         : in  std_logic_vector(1 downto 0);
        branch_cond       : in  std_logic;
        mem_valid         : in  std_logic;
	mem_ready         : in  std_logic;
        regram_wen        : out std_logic;
        regram_wrdata     : out std_logic_vector(31 downto 0);
        mem_valid_execute : out std_logic;
        mem_addr          : out std_logic_vector(31 downto 0);
        mem_wdata         : out std_logic_vector(31 downto 0);
        mem_wstrb         : out std_logic_vector(3 downto 0)
    );
end entity;

architecture Behavioral of cpu_exec is

    constant cpu_state_exec : std_logic_vector(1 downto 0) := "10";
    constant strb1 : std_logic_vector(3 downto 0) := "0001";
    constant strb3 : std_logic_vector(3 downto 0) := "0011";

    signal i_type, r_type, b_type, l_type, s_type : std_logic;			
    signal instr_lui, instr_auipc : std_logic; 		  
    signal instr_jal, instr_jalr, instr_beq, instr_bne, instr_blt, instr_bge, instr_bltu, instr_bgeu : std_logic;
    signal instr_lb, instr_lh, instr_lw, instr_lbu, instr_lhu, instr_sb, instr_sh, instr_sw : std_logic;			  
    signal instr_addi, instr_slti, instr_sltiu, instr_xori, instr_ori, instr_andi, instr_slli, instr_srli, instr_srai : std_logic;
    signal instr_add, instr_sub, instr_sll, instr_slt, instr_sltu, instr_xor, instr_srl, instr_sra, instr_or, instr_and : std_logic;
    signal instr_ecall_ebreak, instr_rdcycle, instr_rdcycleh, instr_rdinstr, instr_rdinstrh : std_logic;


begin

    process(clk, resetn)
    begin
        if resetn = '0' then
                mem_valid_execute <= '0';
                mem_addr          <= (others => '0');
                mem_wstrb         <= (others => '0');
                regram_wen        <= '0';
                regram_wrdata     <= (others => '0');
                mem_wdata         <= (others => '0');
        elsif rising_edge(clk) then

            if cpu_state = cpu_state_exec then
                regram_wen        <= '0';
                regram_wrdata     <= (others => '0');
		
                if instr_rdcycle = '1' then
                    regram_wen    <= '1';
                    regram_wrdata <= counter_reg;
                    mem_addr      <= pc_reg;
                
		elsif instr_rdinstr = '1' then
                    regram_wen    <= '1';
                    regram_wrdata <= counter_instr_reg;
                    mem_addr      <= pc_reg;

                elsif s_type = '1' then
                    if mem_valid = '0' then
                        mem_valid_execute <= '1';
                        mem_addr          <= mem_dest and x"FFFFFFFC"; -- align address

                        if instr_sw = '1' then
                            mem_wstrb <= "1111";
                            mem_wdata <= cpuregs_rs2;

                        elsif instr_sb = '1' then
                            -- Challenge 4: store byte
                            mem_wstrb <= std_logic_vector(shift_left(unsigned(strb1), to_integer(unsigned(mem_dest(1 downto 0)))));
                            mem_wdata <= std_logic_vector(shift_left(unsigned(cpuregs_rs2), to_integer(unsigned(byte_memdest))));

                        elsif instr_sh = '1' then
                            -- Challenge 4: store halfword
                            mem_wstrb <= std_logic_vector(shift_left(unsigned(strb3), to_integer(unsigned(mem_dest(1 downto 0)))));
                            mem_wdata <= std_logic_vector(shift_left(unsigned(cpuregs_rs2), to_integer(unsigned(byte_memdest))));

                        else
                            mem_wstrb <= (others => '0');
                        end if;

                    elsif mem_ready = '1' then
                        mem_valid_execute <= '0';
                        mem_wstrb         <= (others => '0');
                        mem_addr          <= pc_reg;
                    end if;

                elsif l_type = '1' then
                    if mem_valid = '0' then
                        mem_valid_execute <= '1';
                        mem_wstrb         <= (others => '0');
                        mem_addr          <= mem_src and x"FFFFFFFC"; -- align address

                    elsif mem_ready = '1' then
                        mem_valid_execute <= '0';

                        if instr_lw = '1' then
                            regram_wen    <= '1';
                            regram_wrdata <= mem_rdata;

                        elsif instr_lb = '1' then
                            regram_wen <= '1';
                            -- Sign extend byte selected by byte_memsrc
                            case byte_memsrc is
                                when "1000" =>  -- MSB byte
                                    regram_wrdata(7 downto 0)   <= mem_rdata(31 downto 24);
                                    regram_wrdata(31 downto 8)  <= (others => mem_rdata(31));
                                when "0100" =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(23 downto 16);
                                    regram_wrdata(31 downto 8)  <= (others => mem_rdata(23));
                                when "0010" =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(15 downto 8);
                                    regram_wrdata(31 downto 8)  <= (others => mem_rdata(15));
                                when others =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(7 downto 0);
                                    regram_wrdata(31 downto 8)  <= (others => mem_rdata(7));
                            end case;

                        elsif instr_lbu = '1' then
                            regram_wen <= '1';
                            -- Zero extend byte selected by byte_memsrc
                            case byte_memsrc is
                                when "1000" =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(31 downto 24);
                                when "0100" =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(23 downto 16);
                                when "0010" =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(15 downto 8);
                                when others =>
                                    regram_wrdata(7 downto 0)   <= mem_rdata(7 downto 0);
                            end case;
                            regram_wrdata(31 downto 8) <= (others => '0');

                        elsif instr_lh = '1' then
                            regram_wen <= '1';
                            if byte_memsrc(2) = '1' then
                                regram_wrdata(15 downto 0)  <= mem_rdata(31 downto 16);
                                regram_wrdata(31 downto 16) <= (others => mem_rdata(31));
                            else
                                regram_wrdata(15 downto 0)  <= mem_rdata(15 downto 0);
                                regram_wrdata(31 downto 16) <= (others => mem_rdata(15));
                            end if;

                        elsif instr_lhu = '1' then
                            regram_wen <= '1';
                            if byte_memsrc(2) = '1' then
                                regram_wrdata(15 downto 0)  <= mem_rdata(31 downto 16);
                            else
                                regram_wrdata(15 downto 0)  <= mem_rdata(15 downto 0);
                            end if;
                            regram_wrdata(31 downto 16) <= (others => '0');

                        end if;

                        mem_addr <= pc_reg;
                    end if;

                elsif (i_type = '1') or (r_type = '1') then
                    if alu_ready = '1' then
                        regram_wen    <= '1';
                        regram_wrdata <= aluout;
                        mem_addr      <= pc_reg;
                    end if;

                elsif b_type = '1' then
                    if alu_ready = '1' then
                        if branch_cond = '1' then
                            mem_addr <= branch_pc_reg;
                        else
                            mem_addr <= pc_reg;
                        end if;
                    end if;

                elsif instr_lui = '1' then
                    regram_wen <= '1';
                    regram_wrdata(31 downto 12) <= imm_u_type_reg(31 downto 12);
                    regram_wrdata(11 downto 0)  <= (others => '0');
                    mem_addr <= pc_reg;

                elsif instr_auipc = '1' then
                    if alu_ready = '1' then
                        regram_wen    <= '1';
                        regram_wrdata <= aluout;
                        mem_addr      <= pc_reg;
                    end if;

                elsif (instr_jal = '1') or (instr_jalr = '1') then
                    if alu_ready = '1' then
                        regram_wen    <= '1';
                        regram_wrdata <= pc_reg;
                        mem_addr      <= aluout;
                    end if;

                else
                    regram_wen <= '0';
                end if;

            else
                -- Not in exec state: disable write enable
                regram_wen <= '0';
            end if;
        end if;
    end process;

    i_type <= instr_group(0);
    r_type <= instr_group(1);
    b_type <= instr_group(2);
    l_type <= instr_group(3);
    s_type <= instr_group(4);

    instr_lui  <= instr_group(10);
    instr_auipc<= instr_group(11);

    instr_jal  <= instr_group(20);
    instr_jalr <= instr_group(21);
    instr_beq  <= instr_group(22);
    instr_bne  <= instr_group(23);
    instr_blt  <= instr_group(24);
    instr_bge  <= instr_group(25);
    instr_bltu <= instr_group(26);
    instr_bgeu <= instr_group(27);

    instr_lb   <= instr_group(30);
    instr_lh   <= instr_group(31);
    instr_lw   <= instr_group(32);
    instr_lbu  <= instr_group(33);
    instr_lhu  <= instr_group(34);
    instr_sb   <= instr_group(35);
    instr_sh   <= instr_group(36);
    instr_sw   <= instr_group(37);

    instr_addi <= instr_group(40);
    instr_slti <= instr_group(41);
    instr_sltiu<= instr_group(42);
    instr_xori <= instr_group(43);
    instr_ori  <= instr_group(44);
    instr_andi <= instr_group(45);
    instr_slli <= instr_group(46);
    instr_srli <= instr_group(47);
    instr_srai <= instr_group(48);

    instr_add  <= instr_group(50); 
    instr_sub  <= instr_group(51);
    instr_sll  <= instr_group(52);
    instr_slt  <= instr_group(53);
    instr_sltu <= instr_group(54);
    instr_xor  <= instr_group(55);
    instr_srl  <= instr_group(56);
    instr_sra  <= instr_group(57);
    instr_or   <= instr_group(58);
    instr_and  <= instr_group(59);  

    instr_ecall_ebreak <= instr_group(70);
    instr_rdcycle      <= instr_group(71);
    instr_rdcycleh     <= instr_group(72);
    instr_rdinstr      <= instr_group(73);
    instr_rdinstrh     <= instr_group(74);


end architecture Behavioral;
