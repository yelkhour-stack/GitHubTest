library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity instruction_decoder is
    port (
        mem_data_reg : in  std_logic_vector(31 downto 0);	

        func3        : out std_logic_vector(2 downto 0);
        func7        : out std_logic_vector(6 downto 0);
        major_opcode : out std_logic_vector(6 downto 0);

        inst_r_opcode : out std_logic_vector(3 downto 0);
        inst_i_opcode : out std_logic_vector(3 downto 0);

        rs1_reg : out std_logic_vector(4 downto 0);
        rs2_reg : out std_logic_vector(4 downto 0);
        rd_reg  : out std_logic_vector(4 downto 0);

        imm_s_type_reg : out std_logic_vector(11 downto 0);
        imm_i_type_reg : out std_logic_vector(11 downto 0);
        imm_b_type_reg : out std_logic_vector(12 downto 0);
        imm_j_type_reg : out std_logic_vector(20 downto 0);
        imm_u_type_reg : out std_logic_vector(31 downto 0);
	
	instr_group : out std_logic_vector(79 downto 0)
    );
end entity;

architecture Behavioral of instruction_decoder is
        signal func3_v        : std_logic_vector(2 downto 0);
        signal func7_v        : std_logic_vector(6 downto 0);
        signal major_opcode_v : std_logic_vector(6 downto 0);
        signal inst_r_opcode_v : std_logic_vector(3 downto 0);
        signal inst_i_opcode_v : std_logic_vector(3 downto 0);
	
	constant const13 : std_logic_vector(12 downto 0) := (others => '0');
	constant const12 : std_logic_vector(11 downto 0) := (others => '0');
	constant const11 : std_logic_vector(10 downto 0) := (others => '0');

  signal i_type, r_type, b_type, l_type, s_type : std_logic;		      
  signal instr_lui, instr_auipc : std_logic;		
  signal instr_jal, instr_jalr, instr_beq, instr_bne, instr_blt, instr_bge, instr_bltu, instr_bgeu : std_logic;
  signal instr_lb, instr_lh, instr_lw, instr_lbu, instr_lhu, instr_sb, instr_sh, instr_sw : std_logic;  			
  signal instr_addi, instr_slti, instr_sltiu, instr_xori, instr_ori, instr_andi, instr_slli, instr_srli, instr_srai : std_logic;
  signal instr_add, instr_sub, instr_sll, instr_slt, instr_sltu, instr_xor, instr_srl, instr_sra, instr_or, instr_and : std_logic;
  signal instr_ecall_ebreak, instr_rdcycle, instr_rdcycleh, instr_rdinstr, instr_rdinstrh : std_logic;


begin
        -- Extract fields
        func3_v        <= mem_data_reg(14 downto 12);
        func7_v        <= mem_data_reg(31 downto 25);
        major_opcode_v <= mem_data_reg(6 downto 0);

        func3        <= func3_v;
        func7        <= func7_v;
        major_opcode <= major_opcode_v;

        -- Instruction type decoding
        i_type <= '1' when major_opcode_v = "0010011" else '0';
        r_type <= '1' when (major_opcode_v = "0110011") and (func7_v /= "0000001") else '0';
        b_type <= '1' when major_opcode_v = "1100011" else '0';
        l_type <= '1' when major_opcode_v = "0000011" else '0';
        s_type <= '1' when major_opcode_v = "0100011" else '0';

        inst_r_opcode_v(3) <= mem_data_reg(30);
        inst_r_opcode_v(2 downto 0) <= func3_v;
        inst_r_opcode <= inst_r_opcode_v;
	  
        inst_i_opcode_v(2 downto 0) <= func3_v;
	inst_i_opcode_v(3) <= mem_data_reg(30) when func3_v = "101" else '0';
        inst_i_opcode <= inst_i_opcode_v;


        -- Individual instructions decoding
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~ HACHATHON CHALLENGE ~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ START ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
        -- instr_lui   <= ... 
        -- instr_auipc <= ...
	--
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --

        -- Register fields
        rs1_reg <= mem_data_reg(19 downto 15);
        rs2_reg <= mem_data_reg(24 downto 20);
        rd_reg  <= mem_data_reg(11 downto 7);

        -- Immediate fields
        imm_s_type_reg <= mem_data_reg(31 downto 25) & mem_data_reg(11 downto 7);
        imm_i_type_reg <= mem_data_reg(31 downto 20);
        imm_b_type_reg <= mem_data_reg(31) & mem_data_reg(7) & mem_data_reg(30 downto 25) & mem_data_reg(11 downto 8) & '0';	
        imm_j_type_reg <= mem_data_reg(31) & mem_data_reg(19 downto 12) & mem_data_reg(20) & mem_data_reg(30 downto 21) & '0';
        imm_u_type_reg <= mem_data_reg(31 downto 12) & const12;

        -- Special instructions
        instr_ecall_ebreak <= '1' when (major_opcode_v = "1110011") and
                                       (mem_data_reg(31 downto 21) = const11) and
                                       (mem_data_reg(19 downto 7)  = const13)
                              else '0';

        instr_rdcycle <= '1' when (major_opcode_v = "1110011") and
                                  ((mem_data_reg(31 downto 12) = "11000000000000000010") or
                                   (mem_data_reg(31 downto 12) = "11000000000100000010"))
                              else '0';

        instr_rdcycleh <= '1' when (major_opcode_v = "1110011") and
                                   ((mem_data_reg(31 downto 12) = "11001000000000000010") or
                                    (mem_data_reg(31 downto 12) = "11001000000100000010"))
                               else '0';

        instr_rdinstr <= '1' when (major_opcode_v = "1110011") and
                                 (mem_data_reg(31 downto 12) = "11000000001000000010")
                             else '0';

        instr_rdinstrh <= '1' when (major_opcode_v = "1110011") and
                                  (mem_data_reg(31 downto 12) = "11001000001000000010")				  
                              else '0';
			      
	instr_group <= (
       	                0 => i_type,
                        1 => r_type,
                        2 => b_type,
                        3 => l_type,
                        4 => s_type,
                        
			10 => instr_lui, 
	                11 => instr_auipc, 
			
			20 => instr_jal,
			21 => instr_jalr,
		        22 => instr_beq,
                        23 => instr_bne, 
                        24 => instr_blt, 
                        25 => instr_bge, 
                        26 => instr_bltu,
                        27 => instr_bgeu,
			
                        30 => instr_lb, 
                        31 => instr_lh, 
                        32 => instr_lw, 
                        33 => instr_lbu,
                        34 => instr_lhu,
                        35 => instr_sb,
                        36 => instr_sh,
                        37 => instr_sw,
			
                        40 => instr_addi, 
                        41 => instr_slti,
                        42 => instr_sltiu,
                        43 => instr_xori, 
                        44 => instr_ori,  
                        45 => instr_andi, 
                        46 => instr_slli, 
                        47 => instr_srli, 
                        48 => instr_srai, 

                        50 => instr_add,  
                        51 => instr_sub,  
                        52 => instr_sll,  
                        53 => instr_slt,  
                        54 => instr_sltu, 
                        55 => instr_xor,  
                        56 => instr_srl,  
                        57 => instr_sra,  
                        58 => instr_or,   
                        59 => instr_and,  			

                        70 => instr_ecall_ebreak,
                        71 => instr_rdcycle,
                        72 => instr_rdcycleh,
                        73 => instr_rdinstr,
                        74 => instr_rdinstrh,
			others => '0');


end architecture Behavioral;
