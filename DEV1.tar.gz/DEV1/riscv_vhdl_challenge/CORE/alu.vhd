library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity ALUsync is
    port (
        clk    : in  std_logic;
        resetn : in  std_logic;
        valid  : in  std_logic;
        a      : in  std_logic_vector(31 downto 0);
        b      : in  std_logic_vector(31 downto 0);
        ALUop  : in  std_logic_vector(3 downto 0);
        ALUOut : out std_logic_vector(31 downto 0);
        ready  : out std_logic;
        over   : out std_logic  -- '0' indicates no overflow
    );
end entity;

architecture Behavioral of ALUsync is

    -- Define ALU operation constants
    constant p_alu_add  : std_logic_vector(3 downto 0) := "0000";
    constant p_alu_sub  : std_logic_vector(3 downto 0) := "1000";
    constant p_alu_sll  : std_logic_vector(3 downto 0) := "0001";
    constant p_alu_slt  : std_logic_vector(3 downto 0) := "0010";
    constant p_alu_sltu : std_logic_vector(3 downto 0) := "0011";
    constant p_alu_xor  : std_logic_vector(3 downto 0) := "0100";
    constant p_alu_srl  : std_logic_vector(3 downto 0) := "0101";
    constant p_alu_sra  : std_logic_vector(3 downto 0) := "1101";
    constant p_alu_or   : std_logic_vector(3 downto 0) := "0110";
    constant p_alu_and  : std_logic_vector(3 downto 0) := "0111";
    constant p_alussub  : std_logic_vector(3 downto 0) := "1111";

    signal alu_out_reg : std_logic_vector(31 downto 0);
    signal ready_reg   : std_logic := '0';
    signal over_reg    : std_logic := '0';

begin

    process(clk, resetn)
        variable a_signed   : signed(31 downto 0);
        variable b_signed   : signed(31 downto 0);
        variable a_unsigned : unsigned(31 downto 0);
        variable b_unsigned : unsigned(31 downto 0);
        variable result_s   : signed(32 downto 0);  -- 33 bits for overflow detection
        variable result_u   : unsigned(32 downto 0);
        variable shift_amt  : integer range 0 to 31;
        variable temp_out   : std_logic_vector(31 downto 0);
        variable overflow_v : std_logic;
    begin
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~ HACHATHON CHALLENGE ~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ START ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --
        -- if resetn = '0' then
	--    ..
        --elsif rising_edge(clk) then
        --    if valid = '1' then
        --    else
	--    end if;   
        --end if;
	-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ --    
    end process;


end architecture;
