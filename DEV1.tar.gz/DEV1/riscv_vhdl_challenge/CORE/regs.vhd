library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity riscv_reg is
    port (
        clk    : in  std_logic;
        wen    : in  std_logic;
        waddr  : in  std_logic_vector(5 downto 0);
        raddr1 : in  std_logic_vector(5 downto 0);
        raddr2 : in  std_logic_vector(5 downto 0);
        wdata  : in  std_logic_vector(31 downto 0);
        rdata1 : out std_logic_vector(31 downto 0);
        rdata2 : out std_logic_vector(31 downto 0);

        -- Debug outputs, enabled only if SIM_RV32 = true
        dbg_x0  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x1  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x2  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x3  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x4  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x5  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x6  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x7  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x8  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x9  : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x10 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x11 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x12 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x13 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x14 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x15 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x16 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x17 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x18 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x19 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x20 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x21 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x22 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x23 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x24 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x25 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x26 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x27 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x28 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x29 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x30 : out std_logic_vector(31 downto 0) := (others => '0');
        dbg_x31 : out std_logic_vector(31 downto 0) := (others => '0')
    );
end entity;

architecture Behavioral of riscv_reg is

    type reg_array_t is array (0 to 31) of std_logic_vector(31 downto 0);
    signal regs : reg_array_t := (others => (others => '0'));

begin

    -- Write process: synchronous write on rising edge of clk if wen = '1'
    process(clk)
    begin
        if rising_edge(clk) then
            if wen = '1' then
                -- Only use lower 5 bits of waddr for indexing 32 registers
                regs(to_integer(unsigned(waddr(4 downto 0)))) <= wdata;
            end if;
        end if;
    end process;

    -- Asynchronous read ports
    rdata1 <= regs(to_integer(unsigned(raddr1(4 downto 0))));
    rdata2 <= regs(to_integer(unsigned(raddr2(4 downto 0))));

    dbg_x0  <= regs(0);
    dbg_x1  <= regs(1);
    dbg_x2  <= regs(2);
    dbg_x3  <= regs(3);
    dbg_x4  <= regs(4);
    dbg_x5  <= regs(5);
    dbg_x6  <= regs(6);
    dbg_x7  <= regs(7);
    dbg_x8  <= regs(8);
    dbg_x9  <= regs(9);
    dbg_x10 <= regs(10);
    dbg_x11 <= regs(11);
    dbg_x12 <= regs(12);
    dbg_x13 <= regs(13);
    dbg_x14 <= regs(14);
    dbg_x15 <= regs(15);
    dbg_x16 <= regs(16);
    dbg_x17 <= regs(17);
    dbg_x18 <= regs(18);
    dbg_x19 <= regs(19);
    dbg_x20 <= regs(20);
    dbg_x21 <= regs(21);
    dbg_x22 <= regs(22);
    dbg_x23 <= regs(23);
    dbg_x24 <= regs(24);
    dbg_x25 <= regs(25);
    dbg_x26 <= regs(26);
    dbg_x27 <= regs(27);
    dbg_x28 <= regs(28);
    dbg_x29 <= regs(29);
    dbg_x30 <= regs(30);
    dbg_x31 <= regs(31);

end architecture;
