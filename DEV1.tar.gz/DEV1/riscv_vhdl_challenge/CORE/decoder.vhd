library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;

entity cpu_decode is
    port (
        clk       : in  std_logic;
        resetn    : in  std_logic;
        pc_reg    : in  std_logic_vector(31 downto 0);
        cpu_state : in  std_logic_vector(1 downto 0);

	instr_group : in std_logic_vector(79 downto 0);

        imm_s_type_reg : in  std_logic_vector(11 downto 0);
        imm_i_type_reg : in  std_logic_vector(11 downto 0);
        imm_u_type_reg : in  std_logic_vector(31 downto 0);
        imm_j_type_reg : in  std_logic_vector(20 downto 0);
        imm_b_type_reg : in  std_logic_vector(12 downto 0);

        cpuregs_rs1 : in  std_logic_vector(31 downto 0);
        cpuregs_rs2 : in  std_logic_vector(31 downto 0);

        func3 : in  std_logic_vector(2 downto 0);

        new_rs1       : in  std_logic_vector(63 downto 0);
        new_rs2       : in  std_logic_vector(63 downto 0);
        new_rd        : in  std_logic_vector(63 downto 0);

        inst_i_opcode : in  std_logic_vector(3 downto 0);
        inst_r_opcode : in  std_logic_vector(3 downto 0);

        counter_reg : in  std_logic_vector(31 downto 0);
        alu_ready   : in  std_logic;

        mem_dest      : out std_logic_vector(31 downto 0);
        mem_src       : out std_logic_vector(31 downto 0);
        alu_a         : out std_logic_vector(31 downto 0);
        alu_b         : out std_logic_vector(31 downto 0);
        alu_valid     : out std_logic;
        aluop         : out std_logic_vector(3 downto 0);
        branch_pc_reg : out std_logic_vector(31 downto 0)
    );
end entity;

architecture Behavioral of cpu_decode is

    constant cpu_state_decod : std_logic_vector(1 downto 0) := "01";

    constant p_alu_add   : std_logic_vector(3 downto 0) := "0000";
    constant p_alu_sub   : std_logic_vector(3 downto 0) := "1000";
    constant p_alussub   : std_logic_vector(3 downto 0) := "1111";

    -- Helper function for signed conversion of 32-bit std_logic_vector
    function to_signed_32(x : std_logic_vector(31 downto 0)) return signed is
    begin
        return signed(x);
    end function;

    -- Helper function for signed conversion of 12-bit std_logic_vector (sign-extended to 32 bits)
    function to_signed_12(x : std_logic_vector(11 downto 0)) return signed is
        variable extended : signed(31 downto 0);
    begin
        extended := (others => x(11)); -- sign extend
        extended(11 downto 0) := signed(x);
        return extended;
    end function;

    -- Helper function for signed conversion of 13-bit std_logic_vector (sign-extended to 32 bits)
    function to_signed_13(x : std_logic_vector(12 downto 0)) return signed is
        variable extended : signed(31 downto 0);
    begin
        extended := (others => x(12)); -- sign extend
        extended(12 downto 0) := signed(x);
        return extended;
    end function;

    -- Helper function for signed conversion of 21-bit std_logic_vector (sign-extended to 32 bits)
    function to_signed_21(x : std_logic_vector(20 downto 0)) return signed is
        variable extended : signed(31 downto 0);
    begin
        extended := (others => x(20)); -- sign extend
        extended(20 downto 0) := signed(x);
        return extended;
    end function;

  signal i_type, r_type, b_type, l_type, s_type : std_logic;			
  signal instr_lui, instr_auipc : std_logic; 		  
  signal instr_jal, instr_jalr, instr_beq, instr_bne, instr_blt, instr_bge, instr_bltu, instr_bgeu : std_logic;
  signal instr_lb, instr_lh, instr_lw, instr_lbu, instr_lhu, instr_sb, instr_sh, instr_sw : std_logic;			  
  signal instr_addi, instr_slti, instr_sltiu, instr_xori, instr_ori, instr_andi, instr_slli, instr_srli, instr_srai : std_logic;
  signal instr_add, instr_sub, instr_sll, instr_slt, instr_sltu, instr_xor, instr_srl, instr_sra, instr_or, instr_and : std_logic;
  signal instr_ecall_ebreak, instr_rdcycle, instr_rdcycleh, instr_rdinstr, instr_rdinstrh : std_logic;

begin		      

    process(clk, resetn)
    begin
        if resetn = '0' then
                mem_dest      <= (others => '0');
                mem_src       <= (others => '0');
                alu_valid     <= '0';
                aluop         <= (others => '0');
                alu_a         <= (others => '0');
                alu_b         <= (others => '0');
                branch_pc_reg <= (others => '0');

        elsif rising_edge(clk) then
            if cpu_state = cpu_state_decod then
                -- Clear some signals by default
                alu_valid <= '0';

                if instr_ecall_ebreak = '1' then
                    -- In VHDL, simulation control statements like $finish are not synthesizable.
                    -- You may handle this with a flag or external testbench control.
                    -- For now, no action here.
		    report "----------------------------------";
		    report "     Simulation score " & character'val(10) & integer'image(to_integer(unsigned(counter_reg)));
		    report "----------------------------------";
		    stop;

                elsif s_type = '1' then
                    mem_dest <= std_logic_vector(
                        to_signed_32(cpuregs_rs1) + to_signed_12(imm_s_type_reg)
                    );
                    

                elsif l_type = '1' then
                    mem_src <= std_logic_vector(
                        to_signed_32(cpuregs_rs1) + to_signed_12(imm_i_type_reg)
                    );
                    

                elsif i_type = '1' then
                    alu_valid <= '1';
                    alu_a <= cpuregs_rs1;
                    alu_b <= std_logic_vector(to_signed_12(imm_i_type_reg));
                    aluop <= inst_i_opcode;
                    

                elsif r_type = '1' then
                    alu_valid <= '1';
                    alu_a <= cpuregs_rs1;
                    alu_b <= cpuregs_rs2;
                    aluop <= inst_r_opcode;
                    

                elsif instr_lui = '1' then
                    -- No alu operation, trace only

                elsif instr_auipc = '1' then
                    alu_valid <= '1';
                    alu_a <= pc_reg;
                    alu_b <= imm_u_type_reg;
                    aluop <= p_alu_add;
                    

                elsif instr_jal = '1' then
                    alu_valid <= '1';
                    alu_a <= std_logic_vector(to_signed_32(pc_reg));
                    alu_b <= std_logic_vector(to_signed_21(imm_j_type_reg));
                    aluop <= p_alu_add;
                    

                elsif instr_jalr = '1' then
                    alu_valid <= '1';
                    alu_a <= cpuregs_rs1;
                    alu_b <= std_logic_vector(to_signed_12(imm_i_type_reg));
                    aluop <= p_alu_add;
                    

                elsif b_type = '1' then
                    branch_pc_reg <= std_logic_vector(
                        to_signed_32(pc_reg) + to_signed_13(imm_b_type_reg)
                    );
                    alu_valid <= '1';
                    alu_a <= cpuregs_rs1;
                    alu_b <= cpuregs_rs2;
                    if (func3 = "100") or (func3 = "101") then
                        aluop <= p_alussub;
                    else
                        aluop <= p_alu_sub;
                    end if;
                    

                else
                    -- Default case: no operation
                    alu_valid <= '0';
                end if;

            else -- cpu_state /= cpu_state_decod
                if alu_ready = '1' then
                    alu_valid <= '0';
                end if;
            end if;
        end if;
    end process;

    i_type <= instr_group(0);
    r_type <= instr_group(1);
    b_type <= instr_group(2);
    l_type <= instr_group(3);
    s_type <= instr_group(4);

    instr_lui  <= instr_group(10);
    instr_auipc<= instr_group(11);

    instr_jal  <= instr_group(20);
    instr_jalr <= instr_group(21);
    instr_beq  <= instr_group(22);
    instr_bne  <= instr_group(23);
    instr_blt  <= instr_group(24);
    instr_bge  <= instr_group(25);
    instr_bltu <= instr_group(26);
    instr_bgeu <= instr_group(27);

    instr_lb   <= instr_group(30);
    instr_lh   <= instr_group(31);
    instr_lw   <= instr_group(32);
    instr_lbu  <= instr_group(33);
    instr_lhu  <= instr_group(34);
    instr_sb   <= instr_group(35);
    instr_sh   <= instr_group(36);
    instr_sw   <= instr_group(37);

    instr_addi <= instr_group(40);
    instr_slti <= instr_group(41);
    instr_sltiu<= instr_group(42);
    instr_xori <= instr_group(43);
    instr_ori  <= instr_group(44);
    instr_andi <= instr_group(45);
    instr_slli <= instr_group(46);
    instr_srli <= instr_group(47);
    instr_srai <= instr_group(48);

    instr_add  <= instr_group(50); 
    instr_sub  <= instr_group(51);
    instr_sll  <= instr_group(52);
    instr_slt  <= instr_group(53);
    instr_sltu <= instr_group(54);
    instr_xor  <= instr_group(55);
    instr_srl  <= instr_group(56);
    instr_sra  <= instr_group(57);
    instr_or   <= instr_group(58);
    instr_and  <= instr_group(59);  

    instr_ecall_ebreak <= instr_group(70);
    instr_rdcycle      <= instr_group(71);
    instr_rdcycleh     <= instr_group(72);
    instr_rdinstr      <= instr_group(73);
    instr_rdinstrh     <= instr_group(74);

end architecture Behavioral;
