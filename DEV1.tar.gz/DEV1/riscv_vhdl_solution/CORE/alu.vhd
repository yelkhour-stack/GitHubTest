library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity ALUsync is
    port (
        clk    : in  std_logic;
        resetn : in  std_logic;
        valid  : in  std_logic;
        a      : in  std_logic_vector(31 downto 0);
        b      : in  std_logic_vector(31 downto 0);
        ALUop  : in  std_logic_vector(3 downto 0);
        ALUOut : out std_logic_vector(31 downto 0);
        ready  : out std_logic;
        over   : out std_logic  -- '0' indicates no overflow
    );
end entity;

architecture Behavioral of ALUsync is

    -- Define ALU operation constants
    constant p_alu_add  : std_logic_vector(3 downto 0) := "0000";
    constant p_alu_sub  : std_logic_vector(3 downto 0) := "1000";
    constant p_alu_sll  : std_logic_vector(3 downto 0) := "0001";
    constant p_alu_slt  : std_logic_vector(3 downto 0) := "0010";
    constant p_alu_sltu : std_logic_vector(3 downto 0) := "0011";
    constant p_alu_xor  : std_logic_vector(3 downto 0) := "0100";
    constant p_alu_srl  : std_logic_vector(3 downto 0) := "0101";
    constant p_alu_sra  : std_logic_vector(3 downto 0) := "1101";
    constant p_alu_or   : std_logic_vector(3 downto 0) := "0110";
    constant p_alu_and  : std_logic_vector(3 downto 0) := "0111";
    constant p_alussub  : std_logic_vector(3 downto 0) := "1111";

    signal alu_out_reg : std_logic_vector(31 downto 0);
    signal ready_reg   : std_logic := '0';
    signal over_reg    : std_logic := '0';

begin

    process(clk, resetn)
        variable a_signed   : signed(31 downto 0);
        variable b_signed   : signed(31 downto 0);
        variable a_unsigned : unsigned(31 downto 0);
        variable b_unsigned : unsigned(31 downto 0);
        variable result_s   : signed(32 downto 0);  -- 33 bits for overflow detection
        variable result_u   : unsigned(32 downto 0);
        variable shift_amt  : integer range 0 to 31;
        variable temp_out   : std_logic_vector(31 downto 0);
        variable overflow_v : std_logic;
    begin
        if resetn = '0' then
            alu_out_reg <= (others => '0');
            ready_reg <= '0';
            over_reg <= '0';
        elsif rising_edge(clk) then
            if valid = '1' then
                a_signed   := signed(a);
                b_signed   := signed(b);
                a_unsigned := unsigned(a);
                b_unsigned := unsigned(b);
                shift_amt  := to_integer(unsigned(b(4 downto 0)));
                overflow_v := '0';
                temp_out   := (others => '0');

                case ALUop is
                    when p_alu_add =>
                        -- Perform addition with overflow detection
                        result_s := resize(a_signed, 33) + resize(b_signed, 33);
                        temp_out := std_logic_vector(result_s(31 downto 0));
                        -- Overflow detection for signed addition
                        if (a_signed(31) = b_signed(31)) and (temp_out(31) /= a_signed(31)) then
                            overflow_v := '1';
                        else
                            overflow_v := '0';
                        end if;

                    when p_alu_sub =>
                        -- Perform subtraction with overflow detection
			result_s := signed(resize(a_unsigned, 33) - resize(b_unsigned, 33));
                        temp_out := std_logic_vector(result_s(31 downto 0));
			overflow_v := result_s(32);

                    when p_alu_and =>
                        temp_out := a and b;
                        overflow_v := '0';

                    when p_alu_or =>
                        temp_out := a or b;
                        overflow_v := '0';

                    when p_alu_xor =>
                        temp_out := a xor b;
                        overflow_v := '0';

                    when p_alu_sll =>
                        temp_out := std_logic_vector(shift_left(a_unsigned, shift_amt));
                        overflow_v := '0';

                    when p_alu_srl =>
                        temp_out := std_logic_vector(shift_right(a_unsigned, shift_amt));
                        overflow_v := '0';

                    when p_alu_sra =>
                        temp_out := std_logic_vector(shift_right(a_signed, shift_amt));
                        overflow_v := '0';

                    when p_alu_slt =>
                        if a_signed < b_signed then
                            temp_out := (31 downto 1 => '0') & '1';
                        else
                            temp_out := (others => '0');
                        end if;
                        overflow_v := '0';

                    when p_alu_sltu =>
                        if a_unsigned < b_unsigned then
                            temp_out := (31 downto 1 => '0') & '1';
                        else
                            temp_out := (others => '0');
                        end if;
                        overflow_v := '0';

                    when p_alussub =>
                        -- Signed subtraction with overflow detection
                        result_s := resize(a_signed, 33) - resize(b_signed, 33);
                        temp_out := std_logic_vector(result_s(31 downto 0));
			overflow_v := result_s(32);

                    when others =>
                        temp_out := (others => '0');
                        overflow_v := '0';
                end case;

                alu_out_reg <= temp_out;
                over_reg <= overflow_v;
                ready_reg <= '1';
            else
                ready_reg <= '0';
            end if;
            
	    ALUOut <= alu_out_reg;
            ready  <= ready_reg;
            over   <= over_reg;	    
        end if;        
    end process;


end architecture;
